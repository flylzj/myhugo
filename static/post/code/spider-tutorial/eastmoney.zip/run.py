# coding: utf-8
from eastmoney import Eastmoney
from db import Db

def run():
    em = Eastmoney()    # 创建一个Eastmoney实例，用于爬取数据
    db = Db()   # 创建一个Db实例，用于把数据存入数据库
    funds = em.get_fund_codes() # 获取所有基金
    for fund in funds:  # 遍历所有基金
        if db.insert('fund', code=fund.get('fund_code'), name=fund.get('fund_name')):   # 把基金插入数据库中
            print('插入基金', fund.get('fund_name'), '成功')
        stocks = em.get_fund_archives_data(fund.get('fund_code'))    # 获取该基金的所有股票
        for stock in stocks:    # 遍历所有股票
            if db.insert('stock', code=stock.get('stock_code'), name=stock.get('stock_name')):    # 插入该股票进数据库
                print('插入股票 ', stock.get('stock_name'), '成功')
            if db.insert('fund_archives', fund_code=fund.get('fund_code'), stock_code=stock.get('stock_code')): # 把该基金持有该股票的关系插入数据库
                print('插入{}持有{}关系成功'.format(fund.get('fund_code'), stock.get('stock_code')))
    print('爬取完成')

if __name__ == '__main__':
    run()