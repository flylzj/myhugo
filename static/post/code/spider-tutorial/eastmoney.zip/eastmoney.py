# coding: utf-8
import requests
import re
from bs4 import BeautifulSoup

class Eastmoney(object):
    def __init__(self):
        '''
        初始化一些属性
        '''
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36"
        }  # 请求头
        self._session = requests.session()  # 初始化一个session对象，用于发起http请求
        self._session.headers = self.headers  # 更改请求头
        self.fund_url = "http://fund.eastmoney.com/data/rankhandler.aspx"  # 获取基金代码的url
        self.fund_archives_url = "http://fundf10.eastmoney.com/FundArchivesDatas.aspx" # 获取某股票持仓信息的url

    def get_fund_count(self):
        '''
        获取基金总数，在那个fund_url里面他有一个allNum返回了总数，我们只要把他解析出来就好了
        :return: fund_count
        '''
        params = {
            'op': 'ph',
            'dt': 'kf',
            'ft': 'all',
            'rs': '',
            'gs': 0,
            'sc': 'zzf',
            'st': 'desc',
            'sd': '2019-01-12',
            'ed': '2020-01-12',
            'qdii': '',
            'tabSubtype': ',,,,,',
            'pi': 1,
            'pn': 50,
            'dx': 1,
            'v': '0.7637284533252435'
        } # 构造get参数
        try:
            r = self._session.get(self.fund_url, headers=self.headers, params=params) # 发起get请求
            pattern = r'allNum:(\d+)'  # 正则表达式
            allNum = re.search(pattern, r.text).groups()  # 正则查找
            return allNum[0]  # 用groups方法返回的是一个元组，元组内的第一个元素就是匹配到的allNum
        except Exception as e:
            print('get fund count error', e)
            return None

    def get_fund_codes(self, pn=None):
        '''

        :return: codes
        '''
        if pn:  # 我们通过这个参数来让方法返回我们想要数量的基金数量
            all_num = pn
        else:
            all_num = self.get_fund_count()  # 获取基金总数
        if not all_num:  # 这里防止获取总数的方法如果出现了异常，我们在这里加一个默认值10000
            all_num = 10000
        params = {
            'op': 'ph',
            'dt': 'kf',
            'ft': 'all',
            'rs': '',
            'gs': 0,
            'sc': 'zzf',
            'st': 'desc',
            'sd': '2019-01-12',
            'ed': '2020-01-12',
            'qdii': '',
            'tabSubtype': ',,,,,',
            'pi': 1,
            'pn': all_num,
            'dx': 1,
            'v': '0.7637284533252435'
        } # 构造get参数
        try:
            r = self._session.get(self.fund_url, headers=self.headers, params=params) # 发起get请求
            pattern = r"datas:(\[.+])"
            data = re.search(pattern, r.text).groups()
            data = eval(data[0])  # 匹配到的数据是长成这样的["", "", ""]
            funds = []
            for d in data:
                # 每一个d都是一个这样的字符串
                # "257070,国联安优选行业混合,GLAYXHYHH,2020-01-14,2.2288,2.5298,-0.0583,9.9122,10.5062,20.2157,58.8709,108.8651,43.2667,52.0327,13.0854,174.6171,2011-05-23,1,99.3909,1.50%,0.15%,1,0.15%,1,81.8092"
                code = d.split(',') # 通过,分割，第一个和第二个就是我们要的数据
                funds.append(   # 把他添加到要返回的列表中
                    {
                        "fund_code": code[0],
                        "fund_name": code[1]
                    }
                )
            return funds
        except Exception as e:
            print('get fund codes', e)
            return []

    def get_fund_archives_data(self, code):
        '''

        :param code:
        :return:
        '''
        params = {
            'type': 'jjcc',
            'code': code,
            'topline': 10,
            'year': '',
            'month': '',
            'rt': '0.8920412842319152'
        } # 构造get参数
        try:
            r = self._session.get(self.fund_archives_url, headers=self.headers, params=params) # get数据
            pattern = r'<tr>.+?</tr>' # 匹配表达式
            stocks = re.findall(pattern, r.text) # 查找所有符合的表达式的字符串，这里查找出来的结果是所有季度的持股，我们只获取最新的季度
            res = []
            for stock in stocks[1:11]:  # 遍历最新季度的股票
                soup = BeautifulSoup(stock, 'lxml')  # 构造beautifulSoup对象
                info = soup.find_all('td') # 查找所有的td标签，也就是每一列的数据
                stock_code = info[1].text # 获取股票代码
                stock_name = info[2].text # 获取股票名称
                res.append(
                    {
                        'stock_code': stock_code,
                        'stock_name': stock_name
                    }
                ) # 添加到结果列表
            return res # 返回结果
        except Exception as e:
            print('get fund archives data error', e)
            return []


if __name__ == '__main__':
    em = Eastmoney()
    funds = em.get_fund_codes(10)
    for fund in funds:
        print(fund)
        print(em.get_fund_archives_data(fund.get('code')))