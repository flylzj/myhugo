# coding: utf-8
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship

Base = declarative_base() # 创建一个数据表的基类

class Fund(Base):
    '''
    funds表的模型
    '''

    __tablename__ = 'funds' # 表名

    id = Column(Integer, primary_key=True) # id字段，主键
    code = Column(String(32), index=True, nullable=False, unique=True) # code字段， 索引， 不能为空, 唯一
    name = Column(String(128), nullable=False) # name字段，不能为空

    archives = relationship('FundArchive') # 一对多关系，通过这个字段可以获取这个基金投资的所有股票


class Stock(Base):
    '''
    stocks表模型
    '''
    __tablename__ = 'stocks' # 表名

    id = Column(Integer, primary_key=True) # id字段，主键
    code = Column(String(32), index=True, nullable=False, unique=True) # code字段， 索引， 不能为空， 唯一
    name = Column(String(128), nullable=False) # name字段，不能为空

    archives = relationship('FundArchive') # 一对多关系，通过这个字段可以获取投资这个股票的所有基金

class FundArchive(Base):
    '''
    fund_archives表模型，用于记录所有的基金持仓
    '''

    __tablename__ = 'fund_archives'

    id = Column(Integer, primary_key=True) # id字段，主键
    fund_code = Column(String(32), ForeignKey('funds.code')) # 外键，来自funds表的code字段
    stock_code = Column(String(32), ForeignKey('stocks.code')) # 外键，来自stocks表的code字段

    UniqueConstraint(fund_code, stock_code) # 联合约束


if __name__ == '__main__':
    from sqlalchemy import create_engine
    engine = create_engine("mysql+pymysql://root:123456@localhost/eastmoney") # 创建数据库引擎
    Base.metadata.bind = engine # 为开始创建的基类绑定数据库引擎
    Base.metadata.create_all()  # 创建所有还没有创建的表