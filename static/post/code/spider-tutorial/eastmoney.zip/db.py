# coding: utf-8
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import IntegrityError
from model import Base, Fund, FundArchive, Stock
import pymysql

class Db(object):
    def __init__(self):
        self.init_db()
        engine = self._get_engine()
        self._Session = sessionmaker(bind=engine)

    def _get_engine(self):
        db_host = 'localhost'   # 数据库地址
        db_user = 'root'    # 账号
        db_password = '123456'  # 密码
        db_db = 'eastmoney' # 数据库
        mysql_uri = 'mysql+pymysql://{}:{}@{}/{}'.format(
            db_user, db_password, db_host, db_db
        )   # 构造uri
        try:
            engine = create_engine(mysql_uri)   # 生成数据库引擎
            return engine   # 返回引擎用于生成Session
        except Exception as e:
            print('get engine error', e)
            return None

    def init_db(self, drop=False):
        Base.metadata.bind = self._get_engine()
        if drop:    # 如果drop为true就删除数据库中所有的表
            Base.metadata.drop_all()
        Base.metadata.create_all()

    def query(self, t, count=1, **kwargs):
        '''
        这个方法可以查找所有的表
        :param t:
        :param count:
        :param kwargs:
        :return:
        '''
        if t == 'fund':
            table = Fund
        elif t == 'stock':
            table = Stock
        else:
            table = FundArchive

        session = self._Session()    # 创建一个session实例
        try:
            res = session.query(table).filter_by(**kwargs)
            if count == -1:
                return res.all()
            elif count == 1:
                return res.first()
            else:
                return res.limit(count)
        except Exception as e:
            print('query error', e)
        finally:
            session.close()

    def insert(self, t, **kwargs):
        if t == 'fund':
            table = Fund
        elif t == 'stock':
            table = Stock
        else:
            table = FundArchive
        # table是三个模型中的其中一个，用kwargs来创建数据项
        table_ = table(**kwargs)
        session = self._Session()
        try:
            session.add(table_)
            session.commit()
            return True
        except IntegrityError as e:
            print('该数据已存在于数据库中')
        except Exception as e:
            print(type(e))
            print('insert error', e)
        finally:
            session.close()

if __name__ == '__main__':
    db = Db()
    db.init_db(True)